// Amendment Explorer — rendering, search, filtering, diff, detail modal.
(function () {
  var DATA = window.IBCX;
  if (!DATA) { return; }

  var elTiles   = document.getElementById('themeTiles');
  var elStatus  = document.getElementById('statusChips');
  var elSearch  = document.getElementById('search');
  var elCount   = document.getElementById('resultCount');
  var elGrid    = document.getElementById('provGrid');
  var elModal   = document.getElementById('modal');
  var elTimeline = document.getElementById('timeline');
  if (!elGrid) { return; }

  var state = { q: '', theme: 'all', status: 'all' };

  function esc(s) {
    return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  }
  function themeLabel(id) {
    var t = DATA.themes.filter(function (x) { return x.id === id; })[0];
    return t ? t.label : id;
  }
  function roleLabel(id) { return DATA.roles[id] || id; }

  // Word-level diff via LCS -> inline <del>/<ins>.
  function diffWords(before, after) {
    var a = before.split(/(\s+)/), b = after.split(/(\s+)/);
    var m = a.length, n = b.length;
    var dp = [];
    for (var i = 0; i <= m; i++) { dp.push(new Array(n + 1).fill(0)); }
    for (i = m - 1; i >= 0; i--) {
      for (var j = n - 1; j >= 0; j--) {
        dp[i][j] = a[i] === b[j] ? dp[i + 1][j + 1] + 1 : Math.max(dp[i + 1][j], dp[i][j + 1]);
      }
    }
    var out = [];
    i = 0; j = 0;
    while (i < m && j < n) {
      if (a[i] === b[j]) { out.push(esc(a[i])); i++; j++; }
      else if (dp[i + 1][j] >= dp[i][j + 1]) { out.push('<del>' + esc(a[i]) + '</del>'); i++; }
      else { out.push('<ins>' + esc(b[j]) + '</ins>'); j++; }
    }
    while (i < m) { out.push('<del>' + esc(a[i]) + '</del>'); i++; }
    while (j < n) { out.push('<ins>' + esc(b[j]) + '</ins>'); j++; }
    return out.join('');
  }

  function statusChip(status) {
    var label = status === 'live' ? 'Live' : 'Deferred';
    return '<span class="status status--' + status + '">' + label + '</span>';
  }

  function matches(p) {
    if (state.theme !== 'all' && p.theme !== state.theme) { return false; }
    if (state.status !== 'all' && p.status !== state.status) { return false; }
    if (state.q) {
      var hay = (p.section + ' ' + p.title + ' ' + p.summary + ' ' + p.before + ' ' + p.after).toLowerCase();
      if (hay.indexOf(state.q.toLowerCase()) === -1) { return false; }
    }
    return true;
  }

  function renderTiles() {
    var counts = {};
    DATA.provisions.forEach(function (p) { counts[p.theme] = (counts[p.theme] || 0) + 1; });
    var tiles = ['<button class="theme-tile' + (state.theme === 'all' ? ' is-active' : '') + '" data-theme="all">' +
      '<span class="theme-tile__count">' + DATA.provisions.length + '</span>' +
      '<span class="theme-tile__label">All themes</span></button>'];
    DATA.themes.forEach(function (t) {
      tiles.push('<button class="theme-tile' + (state.theme === t.id ? ' is-active' : '') + '" data-theme="' + t.id + '">' +
        '<span class="theme-tile__count">' + (counts[t.id] || 0) + '</span>' +
        '<span class="theme-tile__label">' + esc(t.label) + '</span></button>');
    });
    elTiles.innerHTML = tiles.join('');
  }

  function renderStatusChips() {
    var opts = [['all', 'All'], ['live', 'Live'], ['deferred', 'Deferred']];
    elStatus.innerHTML = opts.map(function (o) {
      return '<button class="chip' + (state.status === o[0] ? ' is-active' : '') + '" data-status="' + o[0] + '">' + o[1] + '</button>';
    }).join('');
  }

  function cardHtml(p) {
    var roles = p.roles.map(function (r) { return '<span class="role-tag">' + esc(roleLabel(r)) + '</span>'; }).join('');
    return '<article class="prov-card" data-id="' + p.id + '" tabindex="0" role="button" aria-label="Open ' + esc(p.section) + '">' +
      '<div class="prov-card__top"><span class="prov-card__section">' + esc(p.section) + '</span>' + statusChip(p.status) + '</div>' +
      '<h3>' + esc(p.title) + '</h3>' +
      '<span class="badge">' + esc(themeLabel(p.theme)) + '</span>' +
      '<p class="prov-card__summary">' + esc(p.summary) + '</p>' +
      '<div class="diff diff--preview">' + diffWords(p.before, p.after) + '</div>' +
      '<div class="prov-card__roles">' + roles + '</div>' +
      '</article>';
  }

  function renderGrid() {
    var list = DATA.provisions.filter(matches);
    elCount.textContent = list.length + ' of ' + DATA.provisions.length + ' provisions';
    elGrid.innerHTML = list.length
      ? list.map(cardHtml).join('')
      : '<p class="note">No provisions match these filters.</p>';
  }

  function findById(id) {
    return DATA.provisions.filter(function (p) { return p.id === id; })[0];
  }

  function openDetail(id) {
    var p = findById(id);
    if (!p) { return; }
    var roles = p.roles.map(function (r) { return '<span class="role-tag">' + esc(roleLabel(r)) + '</span>'; }).join('');
    var sources = (p.sources || []).map(function (s) {
      return '<li><a href="' + esc(s.url) + '" target="_blank" rel="noopener">' + esc(s.label) + '</a></li>';
    }).join('');
    var related = (p.related || []).map(function (rid) {
      var r = findById(rid);
      return r ? '<a class="chip chip--link" href="#p-' + r.id + '">' + esc(r.section) + '</a>' : '';
    }).join('');

    elModal.innerHTML =
      '<div class="modal__panel" role="dialog" aria-modal="true" aria-label="' + esc(p.section) + '">' +
        '<button class="modal__close" aria-label="Close">&times;</button>' +
        '<div class="prov-card__top"><span class="prov-card__section">' + esc(p.section) + '</span>' + statusChip(p.status) + '</div>' +
        '<h2>' + esc(p.title) + '</h2>' +
        '<span class="badge">' + esc(themeLabel(p.theme)) + '</span>' +
        '<div class="prov-card__roles" style="margin:14px 0 4px;">' + roles + '</div>' +

        '<h4 class="modal__h">What changed</h4>' +
        '<div class="diff">' + diffWords(p.before, p.after) + '</div>' +

        '<h4 class="modal__h">Before</h4><p class="modal__text">' + esc(p.before) + '</p>' +
        '<h4 class="modal__h">After</h4><p class="modal__text">' + esc(p.after) + '</p>' +

        '<h4 class="modal__h">In plain terms</h4><p class="modal__text">' + esc(p.explanation) + '</p>' +

        (sources ? '<h4 class="modal__h">Sources</h4><ul class="modal__sources">' + sources + '</ul>' : '') +
        (related ? '<h4 class="modal__h">Related</h4><div class="chips">' + related + '</div>' : '') +
      '</div>';

    elModal.classList.remove('is-hidden');
    document.body.classList.add('modal-open');
    var closeBtn = elModal.querySelector('.modal__close');
    if (closeBtn) { closeBtn.focus(); }
  }

  function closeDetail() {
    elModal.classList.add('is-hidden');
    elModal.innerHTML = '';
    document.body.classList.remove('modal-open');
    if (location.hash.indexOf('#p-') === 0) {
      history.replaceState(null, '', location.pathname + location.search);
    }
  }

  function renderTimeline() {
    if (!elTimeline) { return; }
    elTimeline.innerHTML = DATA.timeline.map(function (m) {
      return '<div class="tl-item"><time>' + esc(m.date) + '</time>' +
        '<h4>' + esc(m.title) + '</h4><p>' + esc(m.note) + '</p></div>';
    }).join('');
  }

  // Events
  elTiles.addEventListener('click', function (e) {
    var b = e.target.closest('[data-theme]');
    if (!b) { return; }
    state.theme = b.getAttribute('data-theme');
    renderTiles(); renderGrid();
  });
  elStatus.addEventListener('click', function (e) {
    var b = e.target.closest('[data-status]');
    if (!b) { return; }
    state.status = b.getAttribute('data-status');
    renderStatusChips(); renderGrid();
  });
  elSearch.addEventListener('input', function () { state.q = elSearch.value; renderGrid(); });

  elGrid.addEventListener('click', function (e) {
    var card = e.target.closest('.prov-card');
    if (card) { location.hash = '#p-' + card.getAttribute('data-id'); }
  });
  elGrid.addEventListener('keydown', function (e) {
    if (e.key !== 'Enter' && e.key !== ' ') { return; }
    var card = e.target.closest('.prov-card');
    if (card) { e.preventDefault(); location.hash = '#p-' + card.getAttribute('data-id'); }
  });

  elModal.addEventListener('click', function (e) {
    if (e.target === elModal || e.target.closest('.modal__close')) { closeDetail(); }
  });
  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape' && !elModal.classList.contains('is-hidden')) { closeDetail(); }
  });

  function syncHash() {
    if (location.hash.indexOf('#p-') === 0) { openDetail(location.hash.slice(3)); }
    else if (!elModal.classList.contains('is-hidden')) { closeDetail(); }
  }
  window.addEventListener('hashchange', syncHash);

  // Init
  renderTiles(); renderStatusChips(); renderGrid(); renderTimeline(); syncHash();
})();
