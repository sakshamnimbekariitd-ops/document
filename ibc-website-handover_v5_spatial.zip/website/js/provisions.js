// ============================================================
// Amendment Explorer — data (illustrative SAMPLE content).
// Replace before/after text and sources with sourced material.
// One object per amended section. Keyed structures below.
// ============================================================
window.IBCX = {
  themes: [
    { id: 'corporate',     label: 'Corporate insolvency' },
    { id: 'liquidation',   label: 'Liquidation' },
    { id: 'crossborder',   label: 'Cross-border' },
    { id: 'msme',          label: 'MSME & pre-pack' },
    { id: 'individual',    label: 'Individuals & guarantors' },
    { id: 'institutional', label: 'Institutional & AA' }
  ],

  roles: {
    creditor: 'Creditor',
    debtor: 'Corporate debtor',
    rp: 'Resolution professional',
    aa: 'Adjudicating authority',
    investor: 'Resolution applicant'
  },

  timeline: [
    { date: 'Aug 2025', title: 'Bill introduced', note: 'Amendment Bill introduced in the Lok Sabha.' },
    { date: 'Sep 2025', title: 'Referred to committee', note: 'Sent to the Standing Committee on Finance for review.' },
    { date: 'Dec 2025', title: 'Committee report', note: 'Report tabled with recommendations.' },
    { date: 'Mar 2026', title: 'Passed by both Houses', note: 'Cleared the Lok Sabha and Rajya Sabha.' },
    { date: 'Apr 2026', title: 'Presidential assent', note: 'Received assent and published in the Gazette.' },
    { date: 'Jun 2026', title: 'First provisions notified', note: 'Initial set of sections brought into force.' },
    { date: 'Jul 2026', title: 'Commencement (ongoing)', note: 'Remaining provisions being notified in phases.' }
  ],

  provisions: [
    {
      id: 's7', section: 'Section 7', theme: 'corporate', status: 'live', roles: ['creditor', 'aa'],
      title: 'Initiation of CIRP by a financial creditor',
      summary: 'Adds a defined default threshold and a firm admission timeline.',
      before: 'A financial creditor may file an application for initiating corporate insolvency resolution process against a corporate debtor before the Adjudicating Authority when a default has occurred.',
      after: 'A financial creditor, either by itself or jointly with other financial creditors, may file an application for initiating corporate insolvency resolution process against a corporate debtor before the Adjudicating Authority when a default of not less than the prescribed threshold has occurred, and the Adjudicating Authority shall admit or reject the application within thirty days.',
      explanation: 'Introduces a prescribed threshold and a thirty-day admission timeline to reduce delay at the admission stage.',
      sources: [{ label: 'IBBI — Code text', url: 'https://ibbi.gov.in' }],
      related: ['s9', 's12']
    },
    {
      id: 's9', section: 'Section 9', theme: 'corporate', status: 'live', roles: ['creditor'],
      title: 'Application by an operational creditor',
      summary: 'Clarifies documents required with a demand notice.',
      before: 'After the expiry of the period of ten days from the delivery of the notice or invoice demanding payment, if the operational creditor does not receive payment from the corporate debtor, the operational creditor may file an application before the Adjudicating Authority.',
      after: 'After the expiry of the period of ten days from the delivery of the notice or invoice demanding payment, if the operational creditor does not receive payment from the corporate debtor or notice of a pre-existing dispute, the operational creditor may file an application, accompanied by the prescribed records of default, before the Adjudicating Authority.',
      explanation: 'Requires records of default to accompany the application and expressly references a pre-existing dispute.',
      sources: [{ label: 'IBBI — Code text', url: 'https://ibbi.gov.in' }],
      related: ['s7']
    },
    {
      id: 's12', section: 'Section 12', theme: 'corporate', status: 'live', roles: ['rp', 'aa'],
      title: 'Time limit for completion of CIRP',
      summary: 'Reinforces the outer limit and treatment of excluded periods.',
      before: 'The corporate insolvency resolution process shall be completed within a period of one hundred and eighty days from the date of admission of the application, extendable once by up to ninety days.',
      after: 'The corporate insolvency resolution process shall mandatorily be completed within a period of three hundred and thirty days from the insolvency commencement date, including any extension and the time taken in legal proceedings, save for periods expressly excluded by regulations.',
      explanation: 'Sets a mandatory 330-day outer limit that includes litigation time, with narrowly excluded periods.',
      sources: [{ label: 'IBBI — Code text', url: 'https://ibbi.gov.in' }],
      related: ['s7']
    },
    {
      id: 's29a', section: 'Section 29A', theme: 'corporate', status: 'live', roles: ['investor'],
      title: 'Persons not eligible to be resolution applicants',
      summary: 'Tightens connected-person disqualifications.',
      before: 'A person shall not be eligible to submit a resolution plan if such person is an undischarged insolvent or has an account classified as a non-performing asset for the specified period.',
      after: 'A person shall not be eligible to submit a resolution plan if such person, or any person acting jointly or in concert with such person, is an undischarged insolvent, has an account classified as a non-performing asset for the specified period, or is a connected person to any of the foregoing.',
      explanation: 'Extends ineligibility to persons acting in concert and to connected persons.',
      sources: [{ label: 'IBBI — Code text', url: 'https://ibbi.gov.in' }],
      related: ['s30']
    },
    {
      id: 's30', section: 'Section 30', theme: 'corporate', status: 'deferred', roles: ['rp', 'creditor'],
      title: 'Submission and approval of a resolution plan',
      summary: 'Proposed clarity on treatment of dissenting creditors (deferred).',
      before: 'The resolution professional shall present to the committee of creditors for its approval such resolution plans which confirm the conditions referred to in this section.',
      after: 'The resolution professional shall present to the committee of creditors for its approval such resolution plans which confirm the conditions referred to in this section, and every plan shall provide for payment to dissenting financial creditors of an amount not less than that payable in the event of liquidation.',
      explanation: 'Would codify a minimum liquidation-value entitlement for dissenting creditors. Not yet notified.',
      sources: [{ label: 'IBBI — Code text', url: 'https://ibbi.gov.in' }],
      related: ['s29a', 's53']
    },
    {
      id: 's53', section: 'Section 53', theme: 'liquidation', status: 'live', roles: ['creditor'],
      title: 'Distribution of assets (waterfall)',
      summary: 'Editorial clarification of priority ordering.',
      before: 'The proceeds from the sale of the liquidation assets shall be distributed in the following order of priority and within such period as may be specified.',
      after: 'The proceeds from the sale of the liquidation assets shall be distributed in the following order of priority, in full or by pro rata within each class, and within such period as may be specified.',
      explanation: 'Adds express pro-rata language within a class where proceeds are insufficient.',
      sources: [{ label: 'IBBI — Code text', url: 'https://ibbi.gov.in' }],
      related: ['s30']
    },
    {
      id: 's240a', section: 'Section 240A', theme: 'msme', status: 'live', roles: ['debtor', 'investor'],
      title: 'Application to micro, small and medium enterprises',
      summary: 'Expands relaxations available to MSMEs.',
      before: 'The provisions of clauses (c) and (h) of section 29A shall not apply to the resolution applicant in respect of a corporate debtor which is a micro, small and medium enterprise.',
      after: 'The provisions of clauses (c) and (h) of section 29A shall not apply to the resolution applicant in respect of a corporate debtor which is a micro, small and medium enterprise, and the Central Government may, by notification, further modify or dispense with other provisions in their application to such enterprises.',
      explanation: 'Gives the Central Government power to further tailor the Code for MSMEs.',
      sources: [{ label: 'IBBI — Code text', url: 'https://ibbi.gov.in' }],
      related: ['s29a']
    },
    {
      id: 's94', section: 'Section 94', theme: 'individual', status: 'deferred', roles: ['debtor'],
      title: 'Application by a debtor to initiate insolvency resolution',
      summary: 'Proposed individual-insolvency initiation route (deferred).',
      before: 'A debtor who commits a default may apply, either personally or through a resolution professional, to the Adjudicating Authority for initiating the insolvency resolution process.',
      after: 'A debtor who commits a default may apply, either personally or through a resolution professional, to the Adjudicating Authority for initiating the insolvency resolution process, provided that no such application shall be made during the pendency of any other process against the same debtor.',
      explanation: 'Adds a bar on parallel proceedings against the same debtor. Awaiting notification.',
      sources: [{ label: 'IBBI — Code text', url: 'https://ibbi.gov.in' }],
      related: []
    },
    {
      id: 's234', section: 'Section 234', theme: 'crossborder', status: 'deferred', roles: ['aa'],
      title: 'Agreements with foreign countries',
      summary: 'Framework enabling cross-border cooperation (deferred).',
      before: 'The Central Government may enter into an agreement with the Government of any country outside India for enforcing the provisions of this Code.',
      after: 'The Central Government may enter into an agreement with the Government of any country outside India for enforcing the provisions of this Code, and may adopt a framework based on reciprocity for recognition of foreign insolvency proceedings.',
      explanation: 'Signals a reciprocity-based cross-border framework, to be operationalised by rules.',
      sources: [{ label: 'IBBI — Code text', url: 'https://ibbi.gov.in' }],
      related: []
    },
    {
      id: 's196', section: 'Section 196', theme: 'institutional', status: 'live', roles: ['aa'],
      title: 'Powers and functions of the Board',
      summary: 'Adds explicit power to specify performance standards.',
      before: 'The Board shall, subject to the general direction of the Central Government, perform all or any of the functions specified, including registering and regulating insolvency professionals and agencies.',
      after: 'The Board shall, subject to the general direction of the Central Government, perform all or any of the functions specified, including registering and regulating insolvency professionals and agencies, and specifying performance standards and outcome benchmarks for regulated persons.',
      explanation: 'Empowers the IBBI to set measurable performance standards for regulated persons.',
      sources: [{ label: 'IBBI — Board', url: 'https://ibbi.gov.in' }],
      related: []
    }
  ]
};
