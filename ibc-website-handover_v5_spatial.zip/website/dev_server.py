#!/usr/bin/env python3
"""Live-reload dev server for the Meridian site.

Serves this folder on http://localhost:8001 and auto-refreshes the
browser whenever any file in the folder changes. No dependencies.

    python dev_server.py

Edit any .html / .css / .js file, save it, and the open tab reloads.
"""

import http.server
import os

ROOT = os.path.dirname(os.path.abspath(__file__))
PORT = 8001

# Injected into every HTML page. Polls /__reload; when the change
# token differs from the last one it saw, it reloads the tab.
LIVERELOAD = (
    b"<script>(function(){let last=null;async function c(){"
    b"try{const r=await fetch('/__reload',{cache:'no-store'});"
    b"const v=await r.text();if(last===null){last=v;}"
    b"else if(v!==last){location.reload();}}catch(e){}}"
    b"setInterval(c,700);})();</script>"
)


def latest_mtime():
    """Newest modification time across the served folder."""
    newest = 0.0
    for dirpath, dirs, files in os.walk(ROOT):
        dirs[:] = [d for d in dirs if not d.startswith('.')]
        for name in files:
            try:
                m = os.path.getmtime(os.path.join(dirpath, name))
                if m > newest:
                    newest = m
            except OSError:
                pass
    return newest


class Handler(http.server.SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=ROOT, **kwargs)

    def end_headers(self):
        # Never cache in dev, so saved edits always show up.
        self.send_header('Cache-Control', 'no-store, must-revalidate')
        super().end_headers()

    def do_GET(self):
        path_only = self.path.split('?', 1)[0]

        if path_only == '/__reload':
            body = str(latest_mtime()).encode()
            self.send_response(200)
            self.send_header('Content-Type', 'text/plain')
            self.send_header('Content-Length', str(len(body)))
            self.end_headers()
            self.wfile.write(body)
            return

        local = self.translate_path(self.path)
        if os.path.isdir(local):
            local = os.path.join(local, 'index.html')

        if local.endswith('.html') and os.path.isfile(local):
            with open(local, 'rb') as fh:
                content = fh.read()
            if b'</body>' in content:
                content = content.replace(b'</body>', LIVERELOAD + b'</body>', 1)
            else:
                content += LIVERELOAD
            self.send_response(200)
            self.send_header('Content-Type', 'text/html; charset=utf-8')
            self.send_header('Content-Length', str(len(content)))
            self.end_headers()
            self.wfile.write(content)
            return

        super().do_GET()

    def log_message(self, fmt, *args):
        if '/__reload' not in (args[0] if args else ''):
            super().log_message(fmt, *args)


if __name__ == '__main__':
    os.chdir(ROOT)
    httpd = http.server.ThreadingHTTPServer(('localhost', PORT), Handler)
    print(f'Meridian dev server -> http://localhost:{PORT}  (live reload on)')
    print('Edit any file and save; the browser reloads automatically. Ctrl+C to stop.')
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print('\nStopped.')
