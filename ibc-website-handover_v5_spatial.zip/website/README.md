# Meridian — IBC & Bankruptcy Advisory (website handover)

A static, multi-page website for an Insolvency & Bankruptcy advisory practice,
with an interactive **Amendment Explorer**. No framework, no build step — just
HTML, CSS, and vanilla JS served by a small Python live-reload dev server.

This package is a complete handover: unzip it on any machine with Python 3 and
you get exactly the site and workflow it was built with.

---

## Run it locally

**Windows (easiest):** double-click **`start.bat`**. It checks for Python, starts
the server in its own window, and opens http://localhost:8001 in your browser.

**Any OS (manual):**
```
python dev_server.py
```
then open http://localhost:8001. Requires **Python 3.7+** (uses only the standard
library — nothing to install).

### Live-edit workflow
`dev_server.py` serves this folder and injects a small script that polls
`/__reload`. When any file's modification time changes, the open tab reloads
automatically. So: edit any `.html` / `.css` / `.js`, save, and the browser
refreshes on its own. Responses are sent with no-cache headers, so you always see
the latest.

---

## File structure

```
website/
├─ index.html              Home — hero, resource cards, about teaser
├─ about.html              About Us — practice intro + team
├─ ibc-code.html           IBC Code — the Code as an accordion (Parts I–V)
├─ explorer.html           Amendments — the interactive explorer
├─ ibbi-regulations.html   IBBI Regulations — regulation cards
├─ current-affairs.html    Current Affairs — dated news list
├─ blog.html               Blog — post cards
├─ css/
│  └─ styles.css           All styles; palette tokens live in :root at the top
├─ js/
│  ├─ layout.js            Shared header/nav/footer (single source of truth),
│  │                       mobile nav, accordion, footer year
│  ├─ provisions.js        Amendment Explorer data (window.IBCX)
│  └─ explorer.js          Explorer: tiles, search, filters, diff, detail modal
├─ dev_server.py           Live-reload static server (port 8001)
├─ start.bat               Double-click launcher (Windows)
├─ CLAUDE.md               Short context file for Claude
├─ README.md               This file (full handover notes)
├─ HANDOVER.txt            Quick start: run + upload steps
└─ .claude/
   └─ launch.json          Preview config for Claude Code's browser preview
```

---

## Pages & navigation

Tabs: **Home · About Us · IBC Code · Amendments · IBBI Regulations · Current
Affairs · Blog** (plus a Contact button).

The nav is defined **once** in `js/layout.js` as the `NAV` array and injected into
every page along with the top bar, header, contact CTA, and footer. To change the
nav everywhere, edit that one array. Each page marks its active tab with
`<body data-page="key">` (the `key` matches the `NAV` entry).

---

## Design system

Palette — CSS custom properties in `css/styles.css` `:root`:

| Token       | Value     | Role                         |
|-------------|-----------|------------------------------|
| `--creme`   | `#F6EFE0` | alternating tint sections    |
| `--ivory`   | `#FBF7EF` | page background, cards        |
| `--plum`    | `#2D1B4E` | headings, dark bands, header  |
| `--royal`   | `#5B2A9D` | links, eyebrows, accents      |
| `--accent`  | `#A100FF` | primary buttons (Accenture purple) |
| `--ink`     | `#1A1023` | body text, top bar, footer    |
| `--muted`   | `#5B4A6B` | secondary text                |

Type: `--font-head` = Inter (clean display, weight 600), `--font-accent` = Fraunces
(italic accent words), `--font-body` = Inter (body). Loaded via the `<link>` in each
page's `<head>`.

Glow/pop palette: `--accent-2` `#C77DFF`, `--pink` `#FF5FB0`, `--cyan` `#5FE0FF`,
`--gold` `#FFD166`; light text on a dark space canvas (`--text`, `--text-soft`,
`--text-dim`).

Visual style — **spatial UI** (visionOS-inspired, dark): an immersive multi-layer
cosmic gradient on `body`, content floating on frosted-glass panels (`--panel`,
`--panel-border`, `--blur`) with soft depth shadows (`--lift-1`, `--lift-2`) and a
glow (`--glow`), big rounded corners (`--radius`, `--radius-lg`), a floating glass
pill header, and gradient-text stat numbers. Interaction: `js/layout.js` adds pointer
**parallax** on the ambient orbs (`.deco`) and **3D tilt** on panels (`.card`,
`.prov-card`, `.theme-tile`, `.post`). Motion is gated on `prefers-reduced-motion`
and `pointer: fine`.

Reusable components (all in `styles.css`): `.btn` / `.btn--accent` / `.btn--ghost`,
`.cards` + `.card`, `.card--link`, `.badge`, `.page-hero` + `.breadcrumb`,
`.accordion`, `.affairs` (news list), `.posts` (blog), and the explorer set
(`.theme-tiles`, `.chip`, `.prov-card`, `.status`, `.role-tag`, `.diff`, `.modal`,
`.timeline`).

---

## Amendment Explorer (`explorer.html`)

Structure inspired by the public "IBC Amendment Explorer". Everything is data-driven:

- **Data** — `js/provisions.js` exposes `window.IBCX` with `themes`, `roles`,
  `timeline`, and `provisions`. Each provision has: `id`, `section`, `theme`,
  `status` (`live` / `deferred`), `roles`, `title`, `summary`, `before`, `after`,
  `explanation`, `sources`, `related`.
- **Logic** — `js/explorer.js` renders theme tiles (with counts), status chips,
  a live text search, the provision cards, a **word-level before/after diff**
  (LCS-based), and a **deep-linkable detail modal** (open `explorer.html#p-<id>`,
  e.g. `#p-s29a`). It also renders the Bill→commencement timeline.

To add or edit provisions, just edit the `provisions` array in
`js/provisions.js` — no code changes needed.

---

## Current state (placeholders to replace)

All of the following are **illustrative samples**, clearly labelled in the UI:

- Brand name **"Meridian"**, phone, and email (in `js/layout.js`).
- Team members (`about.html`), blog posts (`blog.html`), current-affairs items
  (`current-affairs.html`).
- IBC section ranges (accurate to the enacted Code, marked "indicative").
- IBBI regulation summaries (`ibbi-regulations.html`).
- **All amendment provisions** in `js/provisions.js` — the before/after text,
  notes, and sources are demonstrative, not authoritative legal text.

---

## Conventions for extending

- **New page:** copy the `<head>` of an existing page (fonts + `styles.css` +
  `defer` `layout.js`), set `<body data-page="key">`, put content in a `<main>`,
  and add a matching entry to `NAV` in `js/layout.js`. Header/footer inject
  automatically.
- **Interior pages** use a `.page-hero` banner + `.breadcrumb`, then
  `.section` / `.container` blocks.
- Keep it vanilla — no build tooling — so the Python live-reload workflow keeps
  working.

## Ideas / next steps

- Replace sample provisions with real, sourced amendment data.
- Add a guided tour (role → focus → curated path).
- Split Timeline and a Sources compendium into their own tabs.
- Add a side-by-side before/after column view in the detail modal.
- Wire a real contact form and swap in the real firm name and details.
