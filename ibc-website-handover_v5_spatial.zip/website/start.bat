@echo off
cd /d "%~dp0"
title Meridian - IBC website launcher

where python >nul 2>nul
if errorlevel 1 (
  echo.
  echo   Python 3 was not found on your PATH.
  echo   Install it from https://www.python.org/downloads/
  echo   ^(tick "Add python.exe to PATH" during setup^), then run this file again.
  echo.
  pause
  exit /b 1
)

echo.
echo   Starting the local server at http://localhost:8001
echo.
start "Meridian server - keep this window open while working" python dev_server.py
timeout /t 2 /nobreak >nul
start "" http://localhost:8001

echo   The site is now running in a separate window titled
echo   "Meridian server". Close that window to stop the server.
echo.
timeout /t 5 /nobreak >nul
