# Meridian IBC website — handover bundle

Four self-contained handover packages of the same Insolvency & Bankruptcy (IBC/IBBI)
website — one per visual style. Every inner `.zip` is a complete, standalone copy of
the site; they differ **only** in look, not in features or content.

## What's inside

| Package | Visual style |
|---|---|
| `ibc-website-handover_v2.zip` | Baseline (light, original palette) |
| `ibc-website-handover_v3_glassmorphism.zip` | Frosted glass |
| `ibc-website-handover_v4_maximalism.zip` | Bold neo-brutalist |
| `ibc-website-handover_v5_spatial.zip` | Dark spatial (latest) |

`SOP.pdf` / `SOP.md` at the top level are the user procedure (also included inside the
v5 package).

## How to use one

1. Pick a version and unzip it → you get a `website` folder.
2. Double-click `website\start.bat`. It finds Python (installing it automatically via
   winget if missing), then opens the site at http://localhost:8001. Keep the server
   window open; edit any file and the browser auto-reloads.
3. Or continue with Claude: upload that version's `.zip` and say
   *"Read README.md and CLAUDE.md, then let's continue."*

Full steps, prerequisites, and troubleshooting: see `SOP.md` / `SOP.pdf`.

## Notes

- Pure static **HTML / CSS / vanilla JS** + a small Python live-reload server
  (`dev_server.py`, port 8001). No frameworks, no build step.
- Self-contained: no external services or backend. Only needs **Python 3** (the
  launcher auto-installs it) and an internet connection for the web fonts.
- The launcher is IBC-specific — it serves this site only.
