# Handover SOP — Meridian IBC website

How to stand this site up on any machine, or hand it to another Claude, and get
**exactly** what you have now. Two primary methods; the rest are fallbacks.

**Package contents:** the `website` folder holds everything — the pages
(`index.html`, `about.html`, `ibc-code.html`, `explorer.html`,
`ibbi-regulations.html`, `current-affairs.html`, `blog.html`), `css/styles.css`,
`js/` (`layout.js`, `provisions.js`, `explorer.js`), plus `dev_server.py`,
`start.bat`, `README.md`, `CLAUDE.md`, this `SOP.md`, and `.claude/launch.json`.

**Prerequisites:** Python 3 (only for running it locally) and an internet
connection (only for the web fonts). You don't need to install Python yourself —
if it's missing, `start.bat` installs it automatically via winget. There are no
other dependencies (the server uses only Python's standard library).

---

## ⭐ Method 1 — Run it locally with `start.bat` (Windows)

Use this to see and edit the site on your own machine.

1. Copy the zip to the machine and **right-click → Extract All** → you get a
   `website` folder.
2. Open the folder and **double-click `start.bat`**. It locates Python (installing
   it automatically via winget if it's missing), installs any dependencies, and
   starts the server — all in one run. No manual setup.
3. A browser tab opens at **http://localhost:8001**. A separate window titled
   "Meridian server" runs the server — **keep it open** while you work.
4. Edit any file and save → the browser tab **reloads automatically**.
5. To stop: close the "Meridian server" window.

---

## ⭐ Method 2 — Continue with Claude

Use this to keep building with an AI that has full project context.

1. Go to Claude (claude.ai, the Claude desktop app, or Claude Code).
2. **Upload the zip** (`ibc-website-handover_v5_spatial.zip`) — or the unzipped
   `website` folder in Claude Code.
3. Send exactly this message:
   > Read README.md and CLAUDE.md, then let's continue.
4. Claude reads the two docs, learns the stack, palette, structure, current design
   (spatial UI), and conventions, and is ready to work on the real files.
5. **To see it running:**
   - In **Claude Code**: ask it to start the preview — a `.claude/launch.json`
     (name `website`, port 8001) is included, so it serves the exact site.
   - On **claude.ai**: Claude edits the actual files; preview by running Method 1
     locally (the files it produces are the site).

> The site is identical because the zip contains the real source files — Claude
> continues from them, it does not rebuild from a description.

---

## Other ways (fallbacks)

- **No `start.bat`, any OS:** open a terminal in the `website` folder and run
  `python dev_server.py` (Mac/Linux may use `python3`), then open
  http://localhost:8001.
- **No Python, but you have VS Code:** open the folder, install the "Live Server"
  extension, right-click `index.html` → "Open with Live Server" (keeps auto-reload,
  on its own port).
- **Just view it:** double-click `index.html`. The whole site works (pages, the
  Amendments explorer, search, filters, modal); you only lose auto-reload — refresh
  manually after edits.

---

## Is it exactly the same? Yes — with two dependencies

- **The site is byte-identical** — same source files, no device-specific paths.
- Needs **Python 3** to run the local server (Method 1 / fallbacks).
- Needs **internet** for the web fonts (Inter, Fraunces). Offline, the site still
  works but headings fall back to a system font. Everything else (dark space
  backdrop, glass panels, glow, 3D tilt, layout, explorer) is identical offline.

---

## Troubleshooting

| Symptom | Fix |
|---|---|
| Python not found | `start.bat` auto-installs it via winget and continues in the same run. If winget is blocked (some managed PCs), install Python 3 manually (tick "Add python.exe to PATH") and re-run. |
| Browser shows "can't connect" at :8001 | The "Meridian server" window was closed or is still starting — run `start.bat` again and wait 2–3 seconds. |
| "Address already in use" / port 8001 busy | Another server is using 8001. Close it, or change `PORT = 8001` in `dev_server.py` to e.g. `8002` (and open that port). |
| Headings look plain / not styled fancily | You're offline — connect to the internet so the fonts load. |
| Edits don't show | Hard-refresh (Ctrl+F5). If using "just view it", remember there's no auto-reload. |
