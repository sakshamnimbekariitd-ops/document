# Project context for Claude

You are picking up the **Meridian — IBC & Bankruptcy Advisory** website. It is a
static, multi-page site (no framework, no build step) with a tiny Python
live-reload dev server. Read `README.md` for the full handover; the essentials:

- **Run it:** double-click `start.bat` (Windows), or `python dev_server.py` from
  this folder. Serves http://localhost:8001 and auto-reloads the browser on save.
  Requires Python 3.7+.
- **Stack:** plain HTML + CSS + vanilla JS. Fonts: Anton (display, via `@import`) +
  Fraunces (serif accents) + Inter (body).
- **Nav is one source of truth:** the tab list lives in `js/layout.js` (`NAV`
  array). It injects the top bar, header/nav, contact CTA, and footer into every
  page. Each page sets its active tab via `<body data-page="...">`.
- **Palette (CSS variables in `css/styles.css` `:root`):** creme `#F6EFE0`,
  ivory `#FBF7EF` (page bg), plum `#2D1B4E` (headings), royal `#5B2A9D` (links),
  accent `#A100FF` (Accenture purple), ink `#1A1023` (body text), muted `#5B4A6B`.
- **Design:** maximalism (neo-brutalist) — Anton display headings, vivid color pops
  (`--pink` `--gold` `--lime`), thick ink borders (`--edge`) with hard offset shadows
  (`--pop`), dotted-grid + color-bloom background, plus a marquee ticker and floating
  deco shapes injected by `js/layout.js`.
- **Amendment Explorer** (`explorer.html`): data in `js/provisions.js`
  (`window.IBCX`), logic in `js/explorer.js` (theme tiles, search, status filters,
  word-level diff, deep-linkable `#p-<id>` detail modal, timeline).
- **Sample content:** brand name, contact details, team, blog, current-affairs
  items, and all amendment provisions are illustrative placeholders. Replace with
  real, sourced content.

Do not introduce a build step or Node dependency unless asked — the live-reload
workflow depends on the current vanilla setup.
