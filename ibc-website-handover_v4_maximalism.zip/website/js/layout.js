// Shared site layout — one source of truth for header, nav, and footer.
// Loaded with `defer` on every page. Marks the active tab from <body data-page>.
(function () {
  var NAV = [
    { href: 'index.html',             key: 'home',             label: 'Home' },
    { href: 'about.html',             key: 'about',            label: 'About Us' },
    { href: 'ibc-code.html',          key: 'ibc-code',         label: 'IBC Code' },
    { href: 'explorer.html',          key: 'amendments',       label: 'Amendments' },
    { href: 'ibbi-regulations.html',  key: 'ibbi-regulations', label: 'IBBI Regulations' },
    { href: 'current-affairs.html',   key: 'current-affairs',  label: 'Current Affairs' },
    { href: 'blog.html',              key: 'blog',             label: 'Blog' }
  ];

  var page = document.body.getAttribute('data-page') || '';

  var navLinks = NAV.map(function (n) {
    var active = n.key === page ? ' class="active"' : '';
    return '<a href="' + n.href + '"' + active + ' data-nav="' + n.key + '">' + n.label + '</a>';
  }).join('');

  var header =
    '<div class="topbar"><div class="container topbar__inner">' +
      '<span class="topbar__welcome"><span class="dot"></span> Meridian &mdash; Insolvency &amp; Bankruptcy Advisory</span>' +
      '<div class="topbar__contact">' +
        '<a href="tel:+919829555874">&#9742; +91 98295 55874</a>' +
        '<a href="mailto:hello@meridian.com">&#9993; hello@meridian.com</a>' +
      '</div>' +
    '</div></div>' +
    '<header class="header"><div class="container header__inner">' +
      '<a href="index.html" class="brand">' +
        '<span class="brand__mark">M</span>' +
        '<span class="brand__text">MERIDIAN<small>Insolvency &amp; Bankruptcy</small></span>' +
      '</a>' +
      '<button class="nav-toggle" aria-label="Toggle menu" aria-expanded="false"><span></span><span></span><span></span></button>' +
      '<nav class="nav" id="nav">' + navLinks +
        '<a href="#contact" class="btn btn--accent nav__cta">Contact</a>' +
      '</nav>' +
    '</div></header>';

  var footer =
    '<section class="cta" id="contact"><div class="container cta__inner">' +
      '<div><h2>Talk to an insolvency professional.</h2>' +
      '<p>Facing a default, a claim, or a resolution timeline? Let’s talk it through.</p></div>' +
      '<a href="mailto:hello@meridian.com" class="btn btn--accent btn--lg">Get in touch</a>' +
    '</div></section>' +
    '<footer class="footer"><div class="container footer__inner">' +
      '<span>&copy; <span id="year"></span> Meridian Insolvency &amp; Bankruptcy Advisory. All rights reserved.</span>' +
      '<div class="footer__links">' +
        '<a href="ibc-code.html">IBC Code</a>' +
        '<a href="ibbi-regulations.html">IBBI Regulations</a>' +
        '<a href="blog.html">Blog</a>' +
      '</div>' +
    '</div></footer>';

  var deco = '<div class="deco" aria-hidden="true"><span class="c1"></span><span class="c2"></span><span class="c3"></span><span class="c4"></span></div>';
  var tick = '<span>Insolvency &#10022;</span><span>Resolution &#10022;</span><span>IBC 2016 &#10022;</span><span>IBBI &#10022;</span><span>CIRP &#10022;</span><span>Liquidation &#10022;</span><span>Advisory &#10022;</span>';
  var marquee = '<div class="marquee" aria-hidden="true"><div class="marquee__track">' + tick + tick + '</div></div>';

  document.body.insertAdjacentHTML('afterbegin', deco + header + marquee);
  document.body.insertAdjacentHTML('beforeend', footer);

  var y = document.getElementById('year');
  if (y) { y.textContent = new Date().getFullYear(); }

  // Mobile nav
  var toggle = document.querySelector('.nav-toggle');
  var nav = document.getElementById('nav');
  if (toggle && nav) {
    toggle.addEventListener('click', function () {
      var open = nav.classList.toggle('open');
      toggle.setAttribute('aria-expanded', String(open));
    });
    nav.querySelectorAll('a').forEach(function (link) {
      link.addEventListener('click', function () {
        nav.classList.remove('open');
        toggle.setAttribute('aria-expanded', 'false');
      });
    });
  }

  // Accordion (IBC Code page)
  document.querySelectorAll('.accordion__trigger').forEach(function (btn) {
    btn.addEventListener('click', function () {
      btn.closest('.accordion__item').classList.toggle('open');
    });
  });
})();
